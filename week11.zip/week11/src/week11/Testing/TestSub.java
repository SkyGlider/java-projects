package week11.Testing;

/**
 * Created by shuxford
 */
public class TestSub extends TestSuper {
    private void test(){
        //System.out.println(a);
        //System.out.println(getA());
        //System.out.println(CONST);
        //System.out.println(myStatic);
    }
}
