package week11.Testing;

/**
 * Created by shuxford
 */
public class TestSuper {
//    private int a = 7;
//    private final int CONST = 17;
//    private static int myStatic = 27;
//
//    public int getA(){
//        return a;
//    }
}
