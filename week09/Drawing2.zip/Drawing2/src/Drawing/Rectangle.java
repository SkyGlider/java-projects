package Drawing;

import java.awt.*;

public class Rectangle {

    //INSTANCE VARIABLES ========================


    //CONSTRUCTORS



    //ACCESSORS =================================



    //MUTATORS ==================================




    //OTHER METHODS



}

